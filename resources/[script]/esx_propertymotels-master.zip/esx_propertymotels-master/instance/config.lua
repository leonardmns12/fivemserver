Config            = {}
Config.Locale     = 'en'
Config.MaxPlayers = 32
