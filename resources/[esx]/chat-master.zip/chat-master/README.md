# Chat
FiveM Chat System | Works off ESX Framework

# Installation

Add 'ensure Chat' into your server.cfg
Remove all other chats in your resource folders.

# Photo

: https://gyazo.com/db2d20b921edd3028ac5d25a96d19098

# Any Issues Or Help 

https://discord.gg/jC9YgyK
