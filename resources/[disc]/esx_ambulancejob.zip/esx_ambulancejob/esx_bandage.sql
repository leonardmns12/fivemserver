USE `essentialmode`;

INSERT INTO `shops` (name, item, price) VALUES
	('TwentyFourSeven','bandage2',3),
	('RobsLiquor','bandage2', 3),
	('LTDgasoline','bandage2', 3);